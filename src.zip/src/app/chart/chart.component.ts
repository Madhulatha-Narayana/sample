import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as Chart from 'chart.js';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit, AfterViewInit {

  public chartForm: FormGroup;
  public colors: any;
  public janColor: string;
  public febColor: string;
  public marchColor: string;
  public canvas: any;
  public ctx: any;
  public chart: any;
  public value: string = 'bar';

  constructor() {
    this.colors = [{id:1, name:'Red'},
    {id:2, name:'Green'},
    {id:3, name:'Purple'},
    {id:4, name:'Yellow'},
    {id:5, name:'Blue'},
    {id:6, name:'Grey'},
    {id:7, name:'Orange'}];

    this.janColor = 'Green';
    this.febColor = 'Blue';
    this.marchColor = 'Yellow';

    this.chartForm = new FormGroup({
      january: new FormControl('3000', Validators.required),
      janColor: new FormControl(''),
      february: new FormControl('5000', Validators.required),
      febColor: new FormControl(''),
      march: new FormControl('2000', Validators.required),
      marchColor: new FormControl(''),
    });
  }

  ngOnInit(){}

  ngAfterViewInit() {
    console.log(this.chartForm.value);
    this.createChart();
  }

  formChange() {
    this.chart.destroy();
    this.createChart();
  }

  createChart() {
    const values = this.chartForm.value;
    this.chart = new Chart(this.value, {
      type: this.value,
      data: {
        visible: true,
        labels: ['January', 'February', 'March'],
        datasets: [{
            data: [values.january, values.february, values.march],
            label: 'Market Qtr Report',
            backgroundColor: [values.janColor, values.febColor, values.marchColor],
          }]
      },
      options: {
        legend: {
            display: true
        },
        responsive: false,
        display:true,
        scales: {
          yAxes: [{
              ticks: {
                  beginAtZero: true
              }
          }]
      }
      }
    })
  }

  radioClick(value) {
    console.log(value);
    this.value = value;
  }

}
